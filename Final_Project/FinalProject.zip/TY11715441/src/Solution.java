
import org.ejml.simple.SimpleMatrix;

import java.util.*;

/**
 * Solving the LD problem:
 * Representing each linear constraint (equation) in an instance Q using a labled graph (i.e., a finite automation)
 * Since there are m constraints/equations in the instance Q, A graph composition algorithm needs to be implemented to
 * convert the m graphs into one final graph.
 * At last a basic graph search on the final graph is needed to solve the LD problem.
 *
 * The LD problem only has three variables and 2 equations.
 */
public class Solution {

    static boolean debug = true;

    static int[][] A = {
            new int[] {0, 0, 0},
            new int[] {0, 0, 1},
            new int[] {0, 1, 0},
            new int[] {0, 1, 1},
            new int[] {1, 0, 0},
            new int[] {1, 0, 1},
            new int[] {1, 1, 0},
            new int[] {1, 1, 1}
    };
    Map<Integer, int[]> edgeMap;




    /*
     * Preparation 1: Caculate the Cmax
     * Assumption: The equation (3) is valid. In other words, C1,C2,C3 are integers and Constant C is non-negative.
     * Cmax = max | C1d1 + C2d2 + C3d3 + d| where d, d1, d2, d3 are integers on the range [0,1]
     *
     */

    static SimpleMatrix d = new SimpleMatrix(
            new double[][] {
                    new double[] {0d, 0d, 0d, 0d},
                    new double[] {0d, 0d, 0d, 1d},
                    new double[] {0d, 0d, 1d, 0d},
                    new double[] {0d, 0d, 1d, 1d},
                    new double[] {0d, 1d, 0d, 0d},
                    new double[] {0d, 1d, 0d, 1d},
                    new double[] {0d, 1d, 1d, 0d},
                    new double[] {0d, 1d, 1d, 1d},

                    new double[] {1d, 0d, 0d, 0d},
                    new double[] {1d, 0d, 0d, 1d},
                    new double[] {1d, 0d, 1d, 0d},
                    new double[] {1d, 0d, 1d, 1d},
                    new double[] {1d, 1d, 0d, 0d},
                    new double[] {1d, 1d, 0d, 1d},
                    new double[] {1d, 1d, 1d, 0d},
                    new double[] {1d, 1d, 1d, 1d}
            }
    );
    static double getCmax(int[] input) {
        SimpleMatrix c = new SimpleMatrix(
                new double[][] {
                        new double[]{input[0], input[0]},
                        new double[]{input[1], input[1]},
                        new double[]{input[2], input[2]},
                        new double[]{0d, 1d}
                }
        );

        SimpleMatrix product = d.mult(c);

        if (debug) {
            System.out.println(product.toString());
        }
        return product.elementMaxAbs();
    }

    /*
     * Preparation 2: Calculate the KC and bi from Constant C
     * @return an integer array.
     * arr[0] - length of the KC
     * arr[i] - bi
     */
    static int[] getKC(double c) {

        if (c == 0) return new int[]{0};
        if (c < 0) throw new IllegalArgumentException("C must be non-negative");

        if (debug) {
            System.out.println(Long.toBinaryString((long)c));
        }
        char[] arr = Long.toBinaryString((long)c).toCharArray();
        int[] result = new int[arr.length+1];
        result[0] = arr.length;
        for (int i = 1; i <= arr.length; i++) {
            result[i] = arr[arr.length - i] - '0';
        }

        return result;
    }

    /**
     * Algorithm 1 Equation to labeled graph
     * Matrix will be used to represent the graph.
     * Specifically, the matrix will be created with
     * A state represented as row
     * The transition/edge represented as column
     * @param input
     */

    public Solution(int[][] input) {
//        edgeMap = new HashMap<>();
//
//        int i = 0;
//        for (int[] ai : A) {
//            edgeMap.put(i++, ai);
//        }
        LabeledGraph g1 = new LabeledGraph(input[0]);
        LabeledGraph g2 = new LabeledGraph(input[1]);
//        g1.print();
//
//        g2.print();

        boolean[][][][][][][][][] M = cartesianProduct(g1, g2);

        List<Integer> path = search(M, g1, g2);

        if (path.isEmpty()) {
            System.out.printf("No solution has been found");
        } else {
            System.out.println("Found path");
            for (int i = 0; i < path.size(); i++) {

                System.out.printf("(%d, %d, %d)\n", A[i][0], A[i][1], A[i][2]);

            }
        }

    }

    public static void main(String[] args) {
        // Test CMAX
        //double result = getCmax(new int[]{-3, 0, 4});
        //System.out.printf("Cmax is " + Double.toString(result));

        // Test KC
//        int[] KC = getKC(34d);
//
//        System.out.println("Length of binary: " + KC[0]);
//        for (int i = 1; i <= KC[0]; i++) {
//            System.out.printf("%d is %d\n", i, KC[i]);
//        }
//
//        System.out.println(getKC(34d));

        int[][] input = new int[][] {
                {3, -2, -1, 3},
                {6, -4, 1, 3}
        };

        Solution sol = new Solution(input);


    }
    /*
    Algorithm 2
     */
    static boolean[][][][][][][][][] cartesianProduct(LabeledGraph g1, LabeledGraph g2) {

        /*
         result is the cartesian product of g1 and g2.

         After cartesian product, the start state is formed by two different states from g1 and g2. Similarly, the state' is in the same form.

         */
        boolean[][][][][][][][][] result =
                new boolean[g1.cMax*2+1][g1.KC[0]+2][g2.cMax*2+1][g2.KC[0]+2][8][g2.cMax*2+1][g2.KC[0]+2][g2.cMax*2+1][g2.KC[0]+2];

        for (int s1_carry = 0; s1_carry <= 2*g1.cMax; s1_carry++) {
            for (int s1_level = 0; s1_level <= g1.KC[0]+1; s1_level++) {
                for (int s2_carry = 0; s2_carry <= 2*g2.cMax; s2_carry++) {
                    for (int s2_level = 0; s2_level <= g2.KC[0] + 1; s2_level++) {
                        for (int i = 0; i < 8; i++) {

                            // above 5 for-loops give us start states of M which is a combination of state from two equations as start state

                            for (int _s1_carry = 0; _s1_carry <= 2 * g1.cMax; _s1_carry++) {
                                for (int _s1_level = 0; _s1_level <= g1.KC[0] + 1; _s1_level++) {
                                    for (int _s2_carry = 0; _s2_carry <= 2 * g2.cMax; _s2_carry++) {
                                        for (int _s2_level = 0; _s2_level <= g2.KC[0] + 1; _s2_level++) {

                                            // above 5 for-loops give us the end state of M
                                            // Note: i and j represent the Ai. if i == j then a1 = a1' and a2 = a2' and a3 == a3'. See the definition of Solution.A
                                            for (int j = 0; j < 8; j++) {
                                                if (g1.matrix[s1_carry][s1_level][i][_s1_carry][_s1_level]
                                                        && g2.matrix[s2_carry][s2_level][i][_s2_carry][_s2_level]
                                                        && i == j) {
                                                    result[s1_carry][s1_level][s2_carry][s2_level][i][_s1_carry][_s1_level][_s2_carry][_s2_level] = true;
                                                }
                                            }

                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return result;
    }

    /**
     * If no solution has been found, an empty list will be returned. Otherwise, the path will be returned.
     * @param M
     * @param g1
     * @param g2
     * @return
     */
    List<Integer> search(boolean[][][][][][][][][] M, LabeledGraph g1, LabeledGraph g2) {

        Set<Node> visited = new HashSet<>();

        List<Integer> path = new ArrayList<>();
        if (dfs(M, 0, 1, 0, 1, 0, g1.KC[0] + 1, 0, g2.KC[0] + 1, visited, path, g1, g2)) {
            return path;
        }

        return Collections.EMPTY_LIST;
    }

    boolean dfs(boolean[][][][][][][][][] M,
                int c1, int l1, int c2, int l2,
                int target_c1, int target_l1, int target_c2, int target_l2,
                Set<Node> visited,
                List<Integer> path,
                LabeledGraph g1, LabeledGraph g2) {
        if (c1 == target_c1 && l1 == target_l1 && c2 == target_c2 && l2 == target_l2) {
            return true;
        }
        for (int _c1 = 0; _c1 <= 2 * g1.cMax; _c1++) {
            for (int _l1 = 0; _l1 <= g1.KC[0] + 1; _l1++) {

                for (int _c2 = 0; _c2 <= 2 * g2.cMax; _c2++) {
                    for (int _l2 = 0; _l2 <= g2.KC[0] + 1; _l2++) {

                        for (int i = 0; i < 8; i++) {
                            if (M[c1][l1] [c2][l2] [i] [_c1][_l1] [_c2][_l2]) {
                                Node node = new Node(c1, l1, c2, l2, i, _c1, _l1, _c2, _l2);

                                if (!visited.contains(node)) {
                                    path.add(i);
                                    visited.add(node);
                                    if (dfs(M, _c1, _l1, _c2, _l2, target_c1, target_l1, target_c2, target_l2, visited, path, g1, g2)) {
                                        return true;
                                    }
                                    path.remove(path.size() - 1);
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

}

class Node {
    public int c1, l1, c2,l2, i, _c1, _l1, _c2, _l2;

    public Node(int c1, int l1, int c2,int l2, int i, int _c1, int _l1, int _c2,int _l2 ) {
        this.c1 = c1; this.l1 = l1; this.c2 = c2; this.l2 = l2;
        this.i = i;
        this._c1 = _c1; this._l1 = _l1; this._c2 = _c2; this._l2 = _l2;
    }
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Node)) return false;
        Node other = (Node)obj;
        return this.hashCode() == other.hashCode();
    }

    // implement a naive hashCode so we can use it in HashMap without issue.
    public int hashCode() {
        return c1 * 1000000000 + l1 * 100000000 + c2 * 10000000 + l2 * 1000000 + i * 100000 + _c1 * 10000 + _l1* 1000 + _c2 * 10 + _l2;
    }


}

class LabeledGraph {
    /*
     * we are using boolean based matrix to represent the state, transition (Aj) and next state.
     * matrix [carry] [i] [j] [carry'] [i']
     * In order to simply the (a1, a2, a3), we created j -> A[j] mapping so the index j can represewnt the path/transition.
     *
     */
    boolean[][][][][] matrix;

    // input with value of C1, C2, C3 and C
    int[] input;

    // KC[0] is the length of binary format. KC[1..KC[0]] contains the binary value of each bi.
    int[] KC;

    int cMax;

    public LabeledGraph(int[] c) {
        input = new int[4];
        for (int i = 0; i < 4; i++) {
            input[i] = c[i];
        }

        cMax = (int)Solution.getCmax(input);

        KC = Solution.getKC(input[3]);

        matrix = new boolean[cMax*2+1][KC[0]+2][8][cMax*2+1][KC[0]+2];

        for (int s = 0; s <= 2*cMax; s++) {
            int carry = s - cMax;
            for (int level = 0; level <= KC[0]; level++) {
                // we are using brute force to evaluate every state (carry = i, level = j)
                int _level = level+1; // we only consider level+1 as possible valid state
                for (int _s = 0; _s <= 2*cMax; _s++) {
                    int _carry = _s - cMax;


                    for (int i = 0; i < 8; i++) { // iterating every edge A[k]
                        int[] ai = Solution.A[i];

                        int R = c[0] * ai[0] + c[1] * ai[1] + c[2] * ai[2] + KC[level] + carry;

                        if (R % 2 == 0 && R/2 == _carry ) {
                            matrix[s][level][i][_s][_level] = true;
                        }
                    }
                }
            }
        }

    }

    public void print() {
        System.out.printf("\nInput [%d, %d, %d, %d\n", input[0], input[1], input[2], input[3]);
        System.out.printf("cMax = %d\n", cMax);
        System.out.printf("KC " + Arrays.toString(KC));

    }
}
